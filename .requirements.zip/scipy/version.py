
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.4.1'
version = '1.4.1'
full_version = '1.4.1'
git_revision = 'adc4f4f7bab120ccfab9383aba272954a0a12fb0'
release = True

if not release:
    version = full_version
